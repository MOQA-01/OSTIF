#!/bin/sh
output_dir=/Users/moqa/Desktop/OSTIF/
echo $output_dir
